import React from "react";
import "./App.css";

function App() {
  return (
    <div className="App">
      <header className="header">QRCode</header>
      <main className="main" style={{ minHeight: "800px" }}>
        <p>Welcome to my homepage!</p>
      </main>
      <footer className="footer">© 2023 - My Website</footer>
    </div>
  );
}

export default App;
