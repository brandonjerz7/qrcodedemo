import { Router } from "express";
var router = Router();

/* Sample GET Request */
router.get("/sample", function (req, res, next) {
  res.json({ sample: "response" });
});

export default router;
